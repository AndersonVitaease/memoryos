/**
 * GoalRegistry.structural.antipattern.test.ts — Sprint 0 (rede de segurança)
 *
 * Este teste NÃO documenta um bug específico já conhecido — ele é a
 * proteção estrutural contra a RECORRÊNCIA do antipadrão em qualquer
 * goal presente ou futuro registrado no GoalRegistry (inclusive
 * conectores que ainda não existem, ex.: um futuro Dropbox).
 *
 * Varre TODOS os goals registrados (GoalRegistry.listAll()), pega cada
 * `signal` de cada goal (campo público `signals: readonly string[]`), e
 * chama `extractParams(signal)` — enviando o sinal sozinho, exatamente
 * como um usuário mandaria um comando incompleto. Nenhum `query` ou
 * `fileName` resultante pode ser igual ao próprio sinal.
 *
 * LIMITAÇÃO DOCUMENTADA (não corrigida agora, fora do escopo do Sprint 0):
 * este teste cobre apenas o estágio GoalRegistry. Os Semantic Providers
 * (Drive, GitHub) têm suas próprias tabelas de sinais (INTENT_RULES)
 * como constantes privadas, não exportadas — não há como varrê-las
 * genericamente sem alterar código de produção para exportá-las, o que
 * está fora do escopo deste sprint (é uma correção pontual, não uma
 * rede de segurança). Os Antipadrões #3 e #4 (providers) já têm testes
 * dedicados e nomeados explicitamente nos arquivos
 * DriveSemanticProvider.antipattern.test.ts e
 * GitHubSemanticProvider.antipattern.test.ts — mas esses cobrem só os
 * casos hoje conhecidos, não qualquer regra futura de provider
 * automaticamente. Registrar essa lacuna como pendência para avaliação
 * em um sprint futuro (não neste).
 *
 * Estado esperado ANTES do Sprint 3: este teste FALHA (reproduz os
 * Antipadrões #6, #7 e #8 pela via estrutural, não pela via pontual).
 * Estado esperado DEPOIS do Sprint 3: PASSA, e continua protegendo
 * qualquer goal adicionado depois, sem precisar ser atualizado.
 */

import test from "node:test";
import assert from "node:assert/strict";
import { GoalRegistry } from "./GoalRegistry";

test("Nenhum signal de nenhum goal registrado, enviado sozinho, deve virar seu próprio query/fileName", () => {
  const failures: string[] = [];

  for (const def of GoalRegistry.listAll()) {
    for (const signal of def.signals) {
      let result: Record<string, unknown>;
      try {
        result = def.extractParams(signal) as Record<string, unknown>;
      } catch (err) {
        // extractParams não deveria lançar exceção para uma entrada só
        // com o próprio sinal — mas isso é um problema diferente do
        // antipadrão que este teste cobre; registrar e seguir.
        failures.push(`${def.type} / "${signal}" → extractParams lançou exceção: ${(err as Error).message}`);
        continue;
      }

      const lower = signal.toLowerCase().trim();
      for (const field of ["query", "fileName"] as const) {
        const value = result[field];
        if (typeof value === "string" && value.toLowerCase().trim() === lower) {
          failures.push(`${def.type} / signal "${signal}" → ${field}="${value}" (igual ao próprio sinal)`);
        }
      }
    }
  }

  assert.equal(
    failures.length,
    0,
    `${failures.length} ocorrência(s) do antipadrão encontradas:\n` + failures.map((f) => `  - ${f}`).join("\n"),
  );
});
