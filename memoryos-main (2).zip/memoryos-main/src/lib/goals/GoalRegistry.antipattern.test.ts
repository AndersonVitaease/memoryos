/**
 * GoalRegistry.antipattern.test.ts — Sprint 0 (rede de segurança)
 *
 * Estágio do pipeline oficial coberto: GoalRegistry (extractParams).
 *
 * Documenta os Antipadrões #6, #7 e #8 da auditoria: `extractParams` de
 * gmail.searchMessages (linhas 178/180), github.searchCode (linha 716) e
 * drive.searchFiles (linha 537) caem para `msg.trim()` cru quando a
 * extração específica falha.
 *
 * Chama `extractParams` diretamente (obtido via GoalRegistry.listAll()),
 * SEM passar por matchBySignals — isola a função em si, independente de
 * o sinal correspondente ser ou não alcançável hoje pelas regras de
 * matching (drive.searchFiles, por exemplo, é uma ocorrência LATENTE,
 * não alcançável com os sinais atuais, mas a função ainda é defeituosa
 * isoladamente).
 *
 * Estado esperado ANTES do Sprint 3: os testes de antipadrão FALHAM.
 * Estado esperado DEPOIS do Sprint 3: PASSAM.
 */

import test from "node:test";
import assert from "node:assert/strict";
import { GoalRegistry } from "./GoalRegistry";

function extractParamsFor(goalType: string) {
  const def = GoalRegistry.listAll().find((d) => d.type === goalType);
  assert.ok(def, `Goal "${goalType}" precisa estar registrado no GoalRegistry`);
  return def!.extractParams;
}

test("Antipadrão #6 — gmail.searchMessages.extractParams não deve devolver a frase de comando inteira como query", () => {
  const extractParams = extractParamsFor("gmail.searchMessages");
  const msg = "procure emails";
  const result = extractParams(msg) as Record<string, unknown>;
  assert.notEqual(
    typeof result.query === "string" ? result.query.toLowerCase().trim() : result.query,
    msg.toLowerCase().trim(),
    `extractParams("${msg}") devolveu query="${result.query}" — a frase de comando inteira ` +
      `virou a query. Antipadrão #6 (GoalRegistry.ts:178/180).`,
  );
});

test("Antipadrão #7 — github.searchCode.extractParams não deve devolver o próprio comando como query", () => {
  const extractParams = extractParamsFor("github.searchCode");
  for (const msg of ["grep", "locate", "search for"]) {
    const result = extractParams(msg) as Record<string, unknown>;
    assert.notEqual(
      typeof result.query === "string" ? result.query.toLowerCase().trim() : result.query,
      msg.toLowerCase().trim(),
      `extractParams("${msg}") devolveu query="${result.query}" — o próprio comando ` +
        `virou a query. Antipadrão #7 (GoalRegistry.ts:716).`,
    );
  }
});

test("Antipadrão #8 (latente) — drive.searchFiles.extractParams não deve devolver o próprio comando como query", () => {
  const extractParams = extractParamsFor("drive.searchFiles");
  const msg = "buscar";
  const result = extractParams(msg) as Record<string, unknown>;
  assert.notEqual(
    typeof result.query === "string" ? result.query.toLowerCase().trim() : result.query,
    msg.toLowerCase().trim(),
    `extractParams("${msg}") devolveu query="${result.query}" — o próprio comando ` +
      `virou a query. Antipadrão #8 (GoalRegistry.ts:537). Hoje é LATENTE: os sinais ` +
      `atuais de drive.searchFiles não deixam essa entrada ser alcançada via ` +
      `matchBySignals — mas a função, isolada, ainda é defeituosa.`,
  );
});

test("Controle — extractParams de goals corretos (padrão 'stripped || null') não devem regredir", () => {
  const extractParams = extractParamsFor("drive.downloadFile");
  const result = extractParams("baixar o arquivo orcamento") as Record<string, unknown>;
  assert.equal(typeof result.fileName, "string");
  assert.notEqual(result.fileName, "baixar o arquivo orcamento");
});
