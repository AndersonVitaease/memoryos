/**
 * GitHubSemanticProvider.antipattern.test.ts — Sprint 0 (rede de segurança)
 *
 * Estágio do pipeline oficial coberto: Semantic Providers (GitHub).
 *
 * Documenta o Antipadrão #4 da auditoria: `normalized.entity ?? lower.trim()`
 * em GitHubSemanticProvider.ts (linhas 257 e 285) — quando não há entidade,
 * o texto bruto vira query. A linha 231 (computeGHDomainScore) é tratada
 * separadamente e NÃO faz parte deste antipadrão de "query" — não é
 * testada aqui como bug (ver ressalva no plano de implementação: precisa
 * de leitura própria de computeGHDomainScore antes de qualquer alteração).
 *
 * Chama `.detect()` diretamente — isola o estágio do provider, sem
 * depender do ImplicitConnectorIntentDetector nem do GoalRegistry.
 *
 * Estado esperado ANTES do Sprint 2b: os testes de antipadrão FALHAM.
 * Estado esperado DEPOIS do Sprint 2b: PASSAM.
 */

import test from "node:test";
import assert from "node:assert/strict";
import { GitHubSemanticProvider } from "./GitHubSemanticProvider";
import { normalize } from "@/lib/conversation-goal-bridge/NaturalLanguageGoalNormalizer";

// IMPORTANTE — descoberta feita ao RODAR este teste, não presumida:
// GitHubSemanticProvider.detect() exige `match && domain.score > 0`
// (linha ~236) para disparar Case 1. Um sinal totalmente sozinho como
// "grep" cai em Case 3 ("no-github-signal", goalType=null) porque não
// há âncora de domínio (ex.: "github", "repo", "repositorio") na
// mensagem — não é este antipadrão, é apenas ausência de sinal de
// domínio, esperado e correto.
//
// A reprodução real do Antipadrão #4 exige verbo + âncora de domínio
// SEM símbolo/entidade real — confirmado por execução direta:
//   "grep no repositorio"       → query: "grep repositorio"
//   "locate no repo"            → query: "locate repo"
// Ambos incorporam o próprio verbo de comando na query.
const REPRODUCIBLE_CASES = ["grep no repositorio", "locate no repo"];

test("Antipadrão #4 — GitHubSemanticProvider incorpora o verbo de comando na query quando não há símbolo real", () => {
  for (const msg of REPRODUCIBLE_CASES) {
    const lower = msg.toLowerCase();
    const norm = normalize(msg);
    const detection = GitHubSemanticProvider.detect(lower, norm);

    assert.equal(detection.goalType, "github.searchCode", `"${msg}" deveria disparar github.searchCode`);
    const query = (detection.entities as Record<string, unknown>).query;
    const verb = msg.split(" ")[0].toLowerCase();
    assert.equal(
      typeof query === "string" && query.toLowerCase().includes(verb),
      false,
      `GitHubSemanticProvider.detect("${msg}") devolveu entities.query="${query}" — ` +
        `contém o próprio verbo de comando "${verb}". Antipadrão #4 (GitHubSemanticProvider.ts:257/285, ` +
        `"normalized.entity ?? lower.trim()").`,
    );
  }
});
