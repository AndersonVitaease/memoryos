/**
 * DriveSemanticProvider.antipattern.test.ts — Sprint 0 (rede de segurança)
 *
 * Estágio do pipeline oficial coberto: Semantic Providers (Drive).
 *
 * Documenta o Antipadrão #3 da auditoria: a regra de intenção "search"
 * (prioridade 30) faz `query: base.fileName ?? lower.trim()`
 * (DriveSemanticProvider.ts:153) — quando não há fileName extraído, o
 * texto bruto inteiro (o próprio verbo de comando) vira a query.
 *
 * Chama `.detect()` diretamente — não depende do ImplicitConnectorIntentDetector
 * nem do GoalRegistry, para isolar exatamente este estágio.
 *
 * Estado esperado ANTES do Sprint 2a: os testes de antipadrão FALHAM.
 * Estado esperado DEPOIS do Sprint 2a: PASSAM.
 */

import test from "node:test";
import assert from "node:assert/strict";
import { DriveSemanticProvider } from "./DriveSemanticProvider";
import { normalize } from "@/lib/conversation-goal-bridge/NaturalLanguageGoalNormalizer";

// Sinais soltos da regra "search" (prioridade 30) que, sozinhos, não têm
// fileName extraível — confirmado por leitura de INTENT_RULES.
const BARE_SEARCH_SIGNALS = ["buscar", "busque", "procure", "procurar", "encontrar", "pesquisar"];

test("Antipadrão #3 — regra 'search' do DriveSemanticProvider nunca deve devolver o próprio verbo como query", () => {
  for (const signal of BARE_SEARCH_SIGNALS) {
    const lower = signal.toLowerCase();
    const norm = normalize(signal);
    const detection = DriveSemanticProvider.detect(lower, norm);

    assert.equal(detection.goalType, "drive.searchFiles", `sinal "${signal}" deveria disparar a regra search`);
    const query = (detection.entities as Record<string, unknown>).query;
    assert.notEqual(
      typeof query === "string" ? query.toLowerCase().trim() : query,
      lower,
      `DriveSemanticProvider.detect("${signal}") devolveu entities.query="${query}" — ` +
        `o próprio verbo virou a query. Antipadrão #3 (DriveSemanticProvider.ts:153, ` +
        `"query: base.fileName ?? lower.trim()").`,
    );
  }
});

test("Controle — DriveSemanticProvider continua extraindo query real corretamente (não deve regredir)", () => {
  const lower = "buscar arquivo orcamento abril";
  const norm = normalize(lower);
  const detection = DriveSemanticProvider.detect(lower, norm);
  assert.equal(detection.goalType, "drive.searchFiles");
  const entities = detection.entities as Record<string, unknown>;
  assert.equal(typeof entities.fileName === "string" || typeof entities.query === "string", true);
});
